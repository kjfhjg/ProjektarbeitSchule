﻿namespace Projektarbeit
{
    partial class ShopUndUpgrade
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.lbl_MilchkaffeKosten = new System.Windows.Forms.TextBox();
            this.lbl_Milchkaffe = new System.Windows.Forms.TextBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.Milchkaffe = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.lbl_CappuccinoKosten = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.lbl_Cappuccino = new System.Windows.Forms.TextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.Cappuccino = new System.Windows.Forms.PictureBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.lbl_LatteKosten = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.lbl_Latte = new System.Windows.Forms.TextBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.Latte = new System.Windows.Forms.PictureBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.lbl_EspressoKosten = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.lbl_Espresso = new System.Windows.Forms.TextBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.Espresso = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Milchkaffe)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Cappuccino)).BeginInit();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Latte)).BeginInit();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.Espresso)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.lbl_MilchkaffeKosten);
            this.panel1.Controls.Add(this.lbl_Milchkaffe);
            this.panel1.Controls.Add(this.pictureBox3);
            this.panel1.Controls.Add(this.Milchkaffe);
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(320, 154);
            this.panel1.TabIndex = 7;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(225, 132);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(31, 13);
            this.label1.TabIndex = 10;
            this.label1.Text = "Taler";
            // 
            // lbl_MilchkaffeKosten
            // 
            this.lbl_MilchkaffeKosten.BackColor = System.Drawing.SystemColors.Control;
            this.lbl_MilchkaffeKosten.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lbl_MilchkaffeKosten.Enabled = false;
            this.lbl_MilchkaffeKosten.Location = new System.Drawing.Point(207, 118);
            this.lbl_MilchkaffeKosten.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_MilchkaffeKosten.Name = "lbl_MilchkaffeKosten";
            this.lbl_MilchkaffeKosten.Size = new System.Drawing.Size(67, 13);
            this.lbl_MilchkaffeKosten.TabIndex = 9;
            this.lbl_MilchkaffeKosten.Text = "0";
            this.lbl_MilchkaffeKosten.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lbl_Milchkaffe
            // 
            this.lbl_Milchkaffe.BackColor = System.Drawing.SystemColors.Control;
            this.lbl_Milchkaffe.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lbl_Milchkaffe.Enabled = false;
            this.lbl_Milchkaffe.Location = new System.Drawing.Point(209, 29);
            this.lbl_Milchkaffe.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_Milchkaffe.Name = "lbl_Milchkaffe";
            this.lbl_Milchkaffe.Size = new System.Drawing.Size(67, 13);
            this.lbl_Milchkaffe.TabIndex = 8;
            this.lbl_Milchkaffe.Text = "0";
            this.lbl_Milchkaffe.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pictureBox3.Location = new System.Drawing.Point(18, 22);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(151, 112);
            this.pictureBox3.TabIndex = 0;
            this.pictureBox3.TabStop = false;
            // 
            // Milchkaffe
            // 
            this.Milchkaffe.BackColor = System.Drawing.Color.Transparent;
            this.Milchkaffe.BackgroundImage = global::Projektarbeit.Properties.Resources.unknown;
            this.Milchkaffe.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.Milchkaffe.ErrorImage = null;
            this.Milchkaffe.Location = new System.Drawing.Point(175, 59);
            this.Milchkaffe.Name = "Milchkaffe";
            this.Milchkaffe.Size = new System.Drawing.Size(131, 50);
            this.Milchkaffe.TabIndex = 0;
            this.Milchkaffe.TabStop = false;
            this.Milchkaffe.Click += new System.EventHandler(this.Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.lbl_CappuccinoKosten);
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.lbl_Cappuccino);
            this.panel2.Controls.Add(this.pictureBox1);
            this.panel2.Controls.Add(this.Cappuccino);
            this.panel2.Location = new System.Drawing.Point(347, 12);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(320, 154);
            this.panel2.TabIndex = 8;
            // 
            // lbl_CappuccinoKosten
            // 
            this.lbl_CappuccinoKosten.BackColor = System.Drawing.SystemColors.Control;
            this.lbl_CappuccinoKosten.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lbl_CappuccinoKosten.Enabled = false;
            this.lbl_CappuccinoKosten.Location = new System.Drawing.Point(211, 118);
            this.lbl_CappuccinoKosten.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_CappuccinoKosten.Name = "lbl_CappuccinoKosten";
            this.lbl_CappuccinoKosten.Size = new System.Drawing.Size(67, 13);
            this.lbl_CappuccinoKosten.TabIndex = 13;
            this.lbl_CappuccinoKosten.Text = "0";
            this.lbl_CappuccinoKosten.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(231, 132);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(31, 13);
            this.label4.TabIndex = 11;
            this.label4.Text = "Taler";
            // 
            // lbl_Cappuccino
            // 
            this.lbl_Cappuccino.BackColor = System.Drawing.SystemColors.Control;
            this.lbl_Cappuccino.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lbl_Cappuccino.Enabled = false;
            this.lbl_Cappuccino.Location = new System.Drawing.Point(209, 29);
            this.lbl_Cappuccino.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_Cappuccino.Name = "lbl_Cappuccino";
            this.lbl_Cappuccino.Size = new System.Drawing.Size(67, 13);
            this.lbl_Cappuccino.TabIndex = 10;
            this.lbl_Cappuccino.Text = "0";
            this.lbl_Cappuccino.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pictureBox1.Location = new System.Drawing.Point(18, 22);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(151, 112);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // Cappuccino
            // 
            this.Cappuccino.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.Cappuccino.BackgroundImage = global::Projektarbeit.Properties.Resources.unknown2;
            this.Cappuccino.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.Cappuccino.Location = new System.Drawing.Point(175, 59);
            this.Cappuccino.Name = "Cappuccino";
            this.Cappuccino.Size = new System.Drawing.Size(131, 50);
            this.Cappuccino.TabIndex = 0;
            this.Cappuccino.TabStop = false;
            this.Cappuccino.Click += new System.EventHandler(this.Click);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.lbl_LatteKosten);
            this.panel3.Controls.Add(this.label2);
            this.panel3.Controls.Add(this.lbl_Latte);
            this.panel3.Controls.Add(this.pictureBox4);
            this.panel3.Controls.Add(this.Latte);
            this.panel3.Location = new System.Drawing.Point(12, 172);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(320, 154);
            this.panel3.TabIndex = 9;
            // 
            // lbl_LatteKosten
            // 
            this.lbl_LatteKosten.BackColor = System.Drawing.SystemColors.Control;
            this.lbl_LatteKosten.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lbl_LatteKosten.Enabled = false;
            this.lbl_LatteKosten.Location = new System.Drawing.Point(207, 120);
            this.lbl_LatteKosten.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_LatteKosten.Name = "lbl_LatteKosten";
            this.lbl_LatteKosten.Size = new System.Drawing.Size(67, 13);
            this.lbl_LatteKosten.TabIndex = 12;
            this.lbl_LatteKosten.Text = "0";
            this.lbl_LatteKosten.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(225, 134);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(31, 13);
            this.label2.TabIndex = 11;
            this.label2.Text = "Taler";
            // 
            // lbl_Latte
            // 
            this.lbl_Latte.BackColor = System.Drawing.SystemColors.Control;
            this.lbl_Latte.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lbl_Latte.Enabled = false;
            this.lbl_Latte.Location = new System.Drawing.Point(209, 27);
            this.lbl_Latte.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_Latte.Name = "lbl_Latte";
            this.lbl_Latte.Size = new System.Drawing.Size(67, 13);
            this.lbl_Latte.TabIndex = 9;
            this.lbl_Latte.Text = "0";
            this.lbl_Latte.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pictureBox4.Location = new System.Drawing.Point(18, 22);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(151, 112);
            this.pictureBox4.TabIndex = 0;
            this.pictureBox4.TabStop = false;
            // 
            // Latte
            // 
            this.Latte.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.Latte.BackgroundImage = global::Projektarbeit.Properties.Resources.unknown3;
            this.Latte.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.Latte.Location = new System.Drawing.Point(175, 59);
            this.Latte.Name = "Latte";
            this.Latte.Size = new System.Drawing.Size(131, 50);
            this.Latte.TabIndex = 0;
            this.Latte.TabStop = false;
            this.Latte.Click += new System.EventHandler(this.Click);
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.lbl_EspressoKosten);
            this.panel4.Controls.Add(this.label3);
            this.panel4.Controls.Add(this.lbl_Espresso);
            this.panel4.Controls.Add(this.pictureBox6);
            this.panel4.Controls.Add(this.Espresso);
            this.panel4.Location = new System.Drawing.Point(347, 172);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(320, 154);
            this.panel4.TabIndex = 10;
            // 
            // lbl_EspressoKosten
            // 
            this.lbl_EspressoKosten.BackColor = System.Drawing.SystemColors.Control;
            this.lbl_EspressoKosten.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lbl_EspressoKosten.Enabled = false;
            this.lbl_EspressoKosten.Location = new System.Drawing.Point(211, 120);
            this.lbl_EspressoKosten.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_EspressoKosten.Name = "lbl_EspressoKosten";
            this.lbl_EspressoKosten.Size = new System.Drawing.Size(67, 13);
            this.lbl_EspressoKosten.TabIndex = 13;
            this.lbl_EspressoKosten.Text = "0";
            this.lbl_EspressoKosten.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(231, 134);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(31, 13);
            this.label3.TabIndex = 11;
            this.label3.Text = "Taler";
            // 
            // lbl_Espresso
            // 
            this.lbl_Espresso.BackColor = System.Drawing.SystemColors.Control;
            this.lbl_Espresso.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.lbl_Espresso.Enabled = false;
            this.lbl_Espresso.Location = new System.Drawing.Point(211, 30);
            this.lbl_Espresso.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.lbl_Espresso.Name = "lbl_Espresso";
            this.lbl_Espresso.Size = new System.Drawing.Size(67, 13);
            this.lbl_Espresso.TabIndex = 10;
            this.lbl_Espresso.Text = "0";
            this.lbl_Espresso.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // pictureBox6
            // 
            this.pictureBox6.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.pictureBox6.Location = new System.Drawing.Point(18, 22);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(151, 112);
            this.pictureBox6.TabIndex = 0;
            this.pictureBox6.TabStop = false;
            // 
            // Espresso
            // 
            this.Espresso.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.Espresso.BackgroundImage = global::Projektarbeit.Properties.Resources.unknown4;
            this.Espresso.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.Espresso.Location = new System.Drawing.Point(175, 59);
            this.Espresso.Name = "Espresso";
            this.Espresso.Size = new System.Drawing.Size(131, 50);
            this.Espresso.TabIndex = 0;
            this.Espresso.TabStop = false;
            this.Espresso.Click += new System.EventHandler(this.Click);
            // 
            // ShopUndUpgrade
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(687, 341);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "ShopUndUpgrade";
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.ShopUndUpgrade_KeyDown);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Milchkaffe)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Cappuccino)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Latte)).EndInit();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.Espresso)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox Milchkaffe;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox Cappuccino;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox Latte;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox Espresso;
        private System.Windows.Forms.TextBox lbl_Milchkaffe;
        private System.Windows.Forms.TextBox lbl_Cappuccino;
        private System.Windows.Forms.TextBox lbl_Latte;
        private System.Windows.Forms.TextBox lbl_Espresso;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox lbl_MilchkaffeKosten;
        private System.Windows.Forms.TextBox lbl_CappuccinoKosten;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox lbl_LatteKosten;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox lbl_EspressoKosten;
        private System.Windows.Forms.Label label3;
    }
}